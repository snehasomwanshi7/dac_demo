package com.cdac.service;

import java.util.List;

import com.cdac.dto.Job;
import com.cdac.dto.Student;

public interface StudentService {

	boolean studLog (Student student);
	void addStudent(Student student);
	List<Student> selectAll();
}
