package com.cdac.service;

import java.util.List;

import com.cdac.dto.Job;

public interface JobService {

	List<Job> selectAll();
	List<Job> selectAll1();
	void addJob(Job job);
	void removeJob(int jobId);
	Job findJob(int jobId);
	void modifyJob(Job job);
}
