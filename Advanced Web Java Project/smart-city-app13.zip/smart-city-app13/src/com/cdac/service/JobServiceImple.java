package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.JobDao;
import com.cdac.dto.Job;

@Service
public class JobServiceImple implements JobService{

	@Autowired
	private JobDao jobDao;

	@Override
	public List<Job> selectAll() {
		return jobDao.seeAll();
	}
	@Override
	public List<Job> selectAll1() {
		return jobDao.seeAll1();
	}
	@Override
	public void addJob(Job job) {
		jobDao.insertJob(job);
		
	}
	@Override
	public void removeJob(int jobId) {
		jobDao.deleteJob(jobId);
		
	}
	@Override
	public Job findJob(int jobId) {
	return jobDao.searchJob(jobId);
	}
	@Override
	public void modifyJob(Job job) {
		jobDao.updateJob(job);
		
	}
	
	
}
