package com.cdac.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;

import com.cdac.dto.Admin;
import com.cdac.service.AdminService;




@Controller
@SessionAttributes("admin")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping(value = "/logout.htm",method = RequestMethod.GET)
	public String logout(@ModelAttribute Admin admin,HttpSession session,ModelMap map,SessionStatus status,WebRequest request) {
		 status.setComplete();
		 request.removeAttribute("admin", WebRequest.SCOPE_SESSION);
		return "index";
	}

	
	@RequestMapping(value = "/prep_Admin_Login.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("admin", new Admin());
		return "Admin_Login";
	}

	@RequestMapping(value = "/admin_login.htm",method = RequestMethod.POST)
	public String login(@ModelAttribute Admin admin,ModelMap map,HttpSession session) {
				
		boolean b = adminService.adminLog(admin);
		if(b) {
			session.setAttribute("admin", admin); 
			return "Home2";
		}else {
			map.put("admin", new Admin());
			return "Admin_Login";
		    } 
		} 

}
