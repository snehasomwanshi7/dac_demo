package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cdac.dto.Job;
import com.cdac.service.JobService;

@Controller
//@SessionAttributes( "userId" )
public class JobController {

	@Autowired
	private JobService jobService;
	
	@RequestMapping(value = "/Job_Detail.htm",method = RequestMethod.GET)
	public String seeList(ModelMap map,HttpSession session) { 
		
		List<Job> li=jobService.selectAll();
		map.put("jlist",li);
		return "Job_Detail_Page";
	}

	@RequestMapping(value = "/Job_Detail1.htm",method = RequestMethod.GET)
	public String seeList1(ModelMap map,HttpSession session) { 
		
		List<Job> li=jobService.selectAll1();
		map.put("jlist",li);
		return "Job_Detail_Page1";
	}
	
	@RequestMapping(value = "/prep_job_add_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("job", new Job());
		return "Job_Page";
	}
	
	
	@RequestMapping(value = "/job_Reg.htm",method = RequestMethod.POST)
	public String register(Job job,ModelMap map) {
		jobService.addJob(job);
		List<Job> li=jobService.selectAll1();
		map.put("jlist",li);
		return "Job_Detail_Page1";
	}
	
	@RequestMapping(value = "/job_delete.htm",method = RequestMethod.GET)
	public String jobDelete(@RequestParam int jobId,ModelMap map,HttpSession session) {
	
		jobService.removeJob(jobId); 
		List<Job> li=jobService.selectAll1();
		map.put("jlist",li);
		return "Job_Detail_Page1";
		
	}
	@RequestMapping(value = "/job_update_form1.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int jobId,ModelMap map) {
		
		Job jb = jobService.findJob(jobId);
		map.put("job", jb);
		
		return "Job_Update";
	}

	
	
	@RequestMapping(value = "/job_update.htm",method = RequestMethod.POST)
	public String jobUpdate(Job job,ModelMap map,HttpSession session) {
		
     //	job.setJobId(jobId);
		jobService.modifyJob(job);
		List<Job> li=jobService.selectAll1();
		map.put("jlist",li);
		return "Job_Detail_Page1";

		
	}

	
}
