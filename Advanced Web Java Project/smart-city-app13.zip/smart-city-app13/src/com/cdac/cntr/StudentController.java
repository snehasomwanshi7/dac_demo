package com.cdac.cntr;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;

import com.cdac.dto.Job;
import com.cdac.dto.Student;
import com.cdac.service.StudentService;


@Controller
@SessionAttributes("student")
public class StudentController {
	
	@Autowired
	private StudentService studentService;

//	@Autowired
//	private RegValidator regValidator;
	
	@RequestMapping(value = "/logout1.htm",method = RequestMethod.GET)
	public String logout(@ModelAttribute Student student,HttpSession session,ModelMap map,SessionStatus status,WebRequest request) {
		 status.setComplete();
		 request.removeAttribute("student", WebRequest.SCOPE_SESSION);
		return "index";
	}
	
	
	@RequestMapping(value = "/stud_Detail.htm",method = RequestMethod.GET)
	public String seeList(ModelMap map,HttpSession session) { 
		
		List<Student> li=studentService.selectAll();
		map.put("slist",li);
		return "Student_Detail";
	}

	
	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("user", new Student());
		return "Student_Registration";
	}
	
	@RequestMapping(value = "/stud_Reg.htm",method = RequestMethod.POST)
	public String register(Student student,ModelMap map) {
		studentService.addStudent(student);
		return "Student_Login";
	}
	
	
	@RequestMapping(value = "/prep_Student_Login.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("student", new Student());
		return "Student_Login";
	}

	@RequestMapping(value = "/stud_login.htm",method = RequestMethod.POST)
	public String login(@ModelAttribute Student student,ModelMap map,HttpSession session) {
				
		boolean b = studentService.studLog(student);
		if(b) {
			session.setAttribute("student", student); 
			return "Home";
		}else {
			map.put("student", new Student());
			return "Student_Login";
		    } 
		} 

}
