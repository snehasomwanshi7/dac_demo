package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student {
	@Id
	@Column(name="studId")
	private int studId;
	@Column(name="studName")
	private String studName;
	@Column(name="Email")
	private String Email;
	@Column(name="Education")
	private String Education;
	@Column(name = "Password")
	private String Password;
	@Column(name="PhoneNo")
	private String PhoneNo;
	public Student() {
		
	}
	public Student(int studId, String studName, String email, String education, String password, String phoneNo) {
		super();
		this.studId = studId;
		this.studName = studName;
		Email = email;
		Education = education;
		Password = password;
		PhoneNo = phoneNo;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getEducation() {
		return Education;
	}
	public void setEducation(String education) {
		Education = education;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	
	
}