package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "job")
public class Job {
	
	@Id
	@GeneratedValue
	@Column(name = "jobId")
	private int jobId;
	@Column(name = "Company")
	private String Company;
	@Column(name = "jobProfile")
	private String jobProfile;
	@Column(name = "Address")
	private String Address;
	public Job() {
		
	}
	public Job(int jobId, String company, String jobProfile, String address) {
		super();
		this.jobId = jobId;
		Company = company;
		this.jobProfile = jobProfile;
		Address = address;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String getJobProfile() {
		return jobProfile;
	}
	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	

}
