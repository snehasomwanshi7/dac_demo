package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	@Column(name="adminName")
	private String adminName;
	@Column(name = "adminPass")
	private String adminPass;
	public Admin() {
		
	}
	public Admin(String adminName, String adminPass) {
		super();
		this.adminName = adminName;
		this.adminPass = adminPass;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminPass() {
		return adminPass;
	}
	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}
	
	
	
}