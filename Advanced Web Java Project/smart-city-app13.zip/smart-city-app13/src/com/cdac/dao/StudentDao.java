package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Job;
import com.cdac.dto.Student;



public interface StudentDao {
	boolean checkStudent(Student student);
	void insertStudent(Student student);
	List<Student> seeAll();
}

