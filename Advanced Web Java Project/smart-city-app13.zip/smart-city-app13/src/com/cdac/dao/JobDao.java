package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Job;

public interface JobDao {

	
	List<Job> seeAll();
	List<Job> seeAll1();
	void insertJob(Job job);
	void deleteJob(int jobId);
	Job searchJob(int jobId);
	void updateJob(Job job);
}
