package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Job;

@Repository
public class JobDaoImple implements JobDao{

	@Autowired
	private HibernateTemplate hibernateTemplate;
	


	@Override
	public List<Job> seeAll() {
		List<Job> jobList = hibernateTemplate.execute(new HibernateCallback<List<Job>>() {

			@Override
			public List<Job> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Job");
				List<Job> li = q.list();
				System.out.println(li);
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return jobList;
	}
	
	@Override
	public List<Job> seeAll1() {
		List<Job> jobList = hibernateTemplate.execute(new HibernateCallback<List<Job>>() {

			@Override
			public List<Job> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Job");
				List<Job> li = q.list();
				System.out.println(li);
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return jobList;
	}

	@Override
	public void insertJob(Job job) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(job);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}
	
	@Override
	public void deleteJob(int jobId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q=session.createSQLQuery("delete from Job where jobId=?");
				q.setInteger(0, jobId);			
				q.executeUpdate();
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public Job searchJob(int jobId) {
		Job job = hibernateTemplate.execute(new HibernateCallback<Job>() {

			@Override
			public Job doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Job jb = (Job)session.get(Job.class, jobId);
				tr.commit();
				session.flush();
				session.close();
				return jb;
			}
			
		});
		return job;
	}

	@Override
	public void updateJob(Job job) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				Query q=session.createSQLQuery("update Job set Company=?, jobProfile=?, Address=? where jobId=?");
				q.setString(0, job.getCompany());
				q.setString(1, job.getJobProfile());
				q.setString(2, job.getAddress());
				q.setInteger(3, job.getJobId());
				q.executeUpdate();
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	
}
